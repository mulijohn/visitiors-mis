<?php

include ('db.php');

$id=$_GET['rid'];
if($id=="")
{
echo '<script>alert("Sorry ! Wrong Entry") </script>' ;
		header("Location: roombook.php");


}

else{
$view="DELETE FROM `roombook` WHERE id ='$id' ";

	if($re = mysqli_query($con,$view))
	{
		echo '<script>alert("booked room successfully checked out") </script>' ;
		header("Location: checkout.php");
	}


}







?>