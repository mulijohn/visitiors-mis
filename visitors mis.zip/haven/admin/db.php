<?php
$con = mysqli_connect("localhost","root","","haven") or die(mysql_error());

?>